﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace UClient
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[] data;
            DateTime a, b;
            while (true)
            {
                Console.Write("What would you like to send? ");
                string x = Console.ReadLine();
                data = Encoding.ASCII.GetBytes(x);
                try
                {
                    using (var client = new UdpClient())
                    {
                        IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
                        IPAddress ipAddress = ipHostInfo.AddressList[0];
                        IPEndPoint remoteEP = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8000);
                        client.Connect(remoteEP);
                        client.Send(data, data.Length);
                        a = DateTime.Now;
                        data = client.Receive(ref remoteEP);
                        b = DateTime.Now;
                        Console.WriteLine("Received from Server: {0}\nRTT: {1}", Encoding.ASCII.GetString(data), (b - a).ToString());
                        client.Close();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }

        }
    }
}
