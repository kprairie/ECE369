﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TutoringScheduler
{
    class Appointment
    {
        string Name;
        string ID;
        string Course;
        DateTime Date;

        public Appointment(string Name, string ID, string Course, DateTime Date)
        {
            this.Name = Name;
            this.ID = ID;
            this.Course = Course;
            this.Date = Date;
        }

        public String toString()
        {
            string x = "\n";
            return (this.Name + x + this.ID + x + this.Course + x + this.Date.ToString() + x);
        }
    }
}
