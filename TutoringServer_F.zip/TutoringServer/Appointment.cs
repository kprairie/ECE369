﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TutoringServer
{
    class Appointment
    {
        string Name;
        string ID;
        string Course;
        DateTime Date;

        public Appointment(string Name, string ID, string Course, DateTime Date)
        {
            this.Name = Name;
            this.ID = ID;
            this.Course = Course;
            this.Date = Date;
        }

        public Appointment()
        {
            this.Name = "";
            this.ID = "";
            this.Course = "";
            this.Date = new DateTime(1, 1, 1, 1, 1, 1);
        }

        public DateTime getDate()
        {
            return this.Date;
        }

        public String getName()
        {
            return this.Name;
        }

        public String getID()
        {
            return this.ID;
        }

        public String getCourse()
        {
            return this.Course;
        }

        public String apptString()
        {
            string x = "\n";
            return (this.Name + x + this.ID + x + this.Course + x + this.Date.ToString() + x);
        }
    }
}
