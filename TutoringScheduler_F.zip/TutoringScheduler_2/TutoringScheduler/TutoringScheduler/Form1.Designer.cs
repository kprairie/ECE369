﻿namespace TutoringScheduler
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.userDetails = new System.Windows.Forms.GroupBox();
            this.userID = new System.Windows.Forms.TextBox();
            this.userName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.courseSelector = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.courseBox = new System.Windows.Forms.ComboBox();
            this.timeSelection = new System.Windows.Forms.GroupBox();
            this.datePicker = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.clearButton = new System.Windows.Forms.Button();
            this.submitButton = new System.Windows.Forms.Button();
            this.userDetails.SuspendLayout();
            this.courseSelector.SuspendLayout();
            this.timeSelection.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // userDetails
            // 
            this.userDetails.Controls.Add(this.userID);
            this.userDetails.Controls.Add(this.userName);
            this.userDetails.Controls.Add(this.label2);
            this.userDetails.Controls.Add(this.label1);
            this.userDetails.Location = new System.Drawing.Point(5, 119);
            this.userDetails.Margin = new System.Windows.Forms.Padding(1);
            this.userDetails.Name = "userDetails";
            this.userDetails.Padding = new System.Windows.Forms.Padding(1);
            this.userDetails.Size = new System.Drawing.Size(179, 103);
            this.userDetails.TabIndex = 0;
            this.userDetails.TabStop = false;
            this.userDetails.Text = "User ";
            // 
            // userID
            // 
            this.userID.Location = new System.Drawing.Point(64, 68);
            this.userID.Margin = new System.Windows.Forms.Padding(1);
            this.userID.Name = "userID";
            this.userID.Size = new System.Drawing.Size(107, 20);
            this.userID.TabIndex = 3;
            // 
            // userName
            // 
            this.userName.Location = new System.Drawing.Point(64, 21);
            this.userName.Margin = new System.Windows.Forms.Padding(1);
            this.userName.Name = "userName";
            this.userName.Size = new System.Drawing.Size(107, 20);
            this.userName.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 71);
            this.label2.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "ID Number";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 24);
            this.label1.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Full Name";
            // 
            // courseSelector
            // 
            this.courseSelector.Controls.Add(this.label3);
            this.courseSelector.Controls.Add(this.courseBox);
            this.courseSelector.Location = new System.Drawing.Point(186, 119);
            this.courseSelector.Margin = new System.Windows.Forms.Padding(1);
            this.courseSelector.Name = "courseSelector";
            this.courseSelector.Padding = new System.Windows.Forms.Padding(1);
            this.courseSelector.Size = new System.Drawing.Size(164, 103);
            this.courseSelector.TabIndex = 1;
            this.courseSelector.TabStop = false;
            this.courseSelector.Text = "Course Selection";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 43);
            this.label3.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Course";
            // 
            // courseBox
            // 
            this.courseBox.FormattingEnabled = true;
            this.courseBox.Items.AddRange(new object[] {
            "ECE 160",
            "ECE 161",
            "ECE 250",
            "ECE 260",
            "ECE 263",
            "ECE 264"});
            this.courseBox.Location = new System.Drawing.Point(45, 40);
            this.courseBox.Margin = new System.Windows.Forms.Padding(1);
            this.courseBox.Name = "courseBox";
            this.courseBox.Size = new System.Drawing.Size(101, 21);
            this.courseBox.TabIndex = 0;
            this.courseBox.Text = "Select Course";
            // 
            // timeSelection
            // 
            this.timeSelection.Controls.Add(this.datePicker);
            this.timeSelection.Controls.Add(this.label4);
            this.timeSelection.Location = new System.Drawing.Point(353, 119);
            this.timeSelection.Margin = new System.Windows.Forms.Padding(1);
            this.timeSelection.Name = "timeSelection";
            this.timeSelection.Padding = new System.Windows.Forms.Padding(1);
            this.timeSelection.Size = new System.Drawing.Size(193, 103);
            this.timeSelection.TabIndex = 2;
            this.timeSelection.TabStop = false;
            this.timeSelection.Text = "Date and Time";
            // 
            // datePicker
            // 
            this.datePicker.CustomFormat = "MM/dd/yyyy hh:mm tt";
            this.datePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.datePicker.Location = new System.Drawing.Point(34, 40);
            this.datePicker.Margin = new System.Windows.Forms.Padding(1);
            this.datePicker.Name = "datePicker";
            this.datePicker.Size = new System.Drawing.Size(153, 20);
            this.datePicker.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(2, 43);
            this.label4.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Date";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(78, 10);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(391, 90);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // clearButton
            // 
            this.clearButton.BackColor = System.Drawing.Color.Gold;
            this.clearButton.Location = new System.Drawing.Point(108, 234);
            this.clearButton.Margin = new System.Windows.Forms.Padding(1);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(76, 46);
            this.clearButton.TabIndex = 4;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = false;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // submitButton
            // 
            this.submitButton.BackColor = System.Drawing.Color.RoyalBlue;
            this.submitButton.Location = new System.Drawing.Point(358, 234);
            this.submitButton.Margin = new System.Windows.Forms.Padding(1);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(76, 46);
            this.submitButton.TabIndex = 5;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = false;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(551, 296);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.timeSelection);
            this.Controls.Add(this.courseSelector);
            this.Controls.Add(this.userDetails);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(1);
            this.Name = "Form1";
            this.Text = "UMD Tutoring";
            this.userDetails.ResumeLayout(false);
            this.userDetails.PerformLayout();
            this.courseSelector.ResumeLayout(false);
            this.courseSelector.PerformLayout();
            this.timeSelection.ResumeLayout(false);
            this.timeSelection.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox userDetails;
        private System.Windows.Forms.TextBox userID;
        private System.Windows.Forms.TextBox userName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox courseSelector;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox courseBox;
        private System.Windows.Forms.GroupBox timeSelection;
        private System.Windows.Forms.DateTimePicker datePicker;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button submitButton;
    }
}

