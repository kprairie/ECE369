﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace TutoringServer_Final
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Thread t = new Thread(StartListening);
            t.Start();
        }


        public void StartListening()
        {
            // Data to be received
            string data, name, ID, course, date;
            string[] words;
            DateTime Date;
            Boolean avail = true;

            // Data buffer for incoming data.  
            byte[] bytes = new Byte[1024];

            // Establish the local endpoint for the socket.  
            // Dns.GetHostName returns the name of the   
            // host running the application.  
            IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress ipAddress = ipHostInfo.AddressList[0];
            IPEndPoint localEndPoint = new IPEndPoint(ipAddress, 10002);

            // Create a TCP/IP socket.  
            Socket listener = new Socket(ipAddress.AddressFamily,
                SocketType.Stream, ProtocolType.Tcp);

            // Bind the socket to the local endpoint and   
            // listen for incoming connections.  
            try
            {
                listener.Bind(localEndPoint);
                listener.Listen(10);

                // Start listening for connections.  
                while (true)
                {
                    Console.WriteLine("Waiting for a connection...");
                    // Program is suspended while waiting for an incoming connection.  
                    data = null;
                    name = null;
                    ID = null;
                    course = null;
                    words = null;
                    List<Appointment> appts = new List<Appointment>();
                    Appointment a = new Appointment();
                    appts.Add(a);
                    Socket handler = listener.Accept();
                    // An incoming connection needs to be processed.  
                    while (true)
                    {
                        int bytesRec = handler.Receive(bytes);
                        data += Encoding.ASCII.GetString(bytes, 0, bytesRec);
                        if (data.IndexOf("PM") > -1 || data.IndexOf("AM") > -1)
                        {
                            break;
                        }
                    }

                    // Show the data on the console.  
                    Console.WriteLine("Text received : {0}", data);

                    // Split data and store to variables
                    words = data.Split(' ');
                    name = words[0] + " " + words[1];
                    ID = words[2];
                    course = words[3] + " " + words[4];
                    date = words[5] + " " + words[6] + " " + words[7];
                    Date = Convert.ToDateTime(date);

                    // Create appointment with elements received. 

                    Appointment newAppointment = new Appointment(name, ID, course, Date);
                    Console.WriteLine("Name: {0}\nID: {1}\nCourse: {2}\nDate: {3}\n", newAppointment.getName(), newAppointment.getID(), newAppointment.getCourse(), newAppointment.getDate().ToString());

                    // Check if Appointment is available

                    foreach (Appointment x in appts)
                    {
                        if ((newAppointment.getDate().ToString() == x.getDate().ToString() && newAppointment.getCourse() == x.getCourse()) || (newAppointment.getID() == x.getID() && newAppointment.getDate().ToString() == x.getDate().ToString()))
                        {
                            byte[] msg = Encoding.ASCII.GetBytes("This time slot is unavailable for this course or You already have an appointment scheduled for this time. Please select another time.");
                            handler.Send(msg);
                            avail = false;
                            break;
                        }
                        else
                            avail = true;
                    }

                    if (avail)
                    {
                        apptList.Items.Add(newAppointment.apptString());
                        appts.Add(newAppointment);
                        byte[] msg = Encoding.ASCII.GetBytes("Your session has been booked. See you soon!");
                        handler.Send(msg);
                    }
                    apptList.Refresh();
                    handler.Shutdown(SocketShutdown.Both);
                    handler.Close();
                    // Print out all appointments. 

                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

        }
    }
}
