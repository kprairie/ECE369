﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace UServer
{
    class Program
    {
        public static void Main()
        {
            byte[] data = new byte[1024];
            string x;
            IPEndPoint ipep = new IPEndPoint(IPAddress.Any, 8000);
            UdpClient newsock = new UdpClient(ipep);

            Console.WriteLine("Waiting for a client...");

            IPEndPoint sender = new IPEndPoint(IPAddress.Any, 0);

            data = newsock.Receive(ref sender);

            Console.WriteLine("Message received from {0}:", sender.ToString());
            Console.WriteLine(Encoding.ASCII.GetString(data, 0, data.Length));

            x = Encoding.ASCII.GetString(data).ToUpper();
            data = Encoding.ASCII.GetBytes(x);
            newsock.Send(data, data.Length, sender);

            while (true)
            {
                data = newsock.Receive(ref sender);
                Console.WriteLine(Encoding.ASCII.GetString(data, 0, data.Length));
                x = Encoding.ASCII.GetString(data, 0, data.Length).ToUpper();
                data = Encoding.ASCII.GetBytes(x);
                newsock.Send(data, data.Length, sender);
            }
        }
    }
}
